/*
This file is part of tuyaUIweb project (https://github.com/msillano/TuyaUIweb)
 Contains user data and options 
 ------------------------------
License MIT
(C)2024 marco.sillano@gmail.com
version 1.1 20/05/2024
*/
// ========== CONFIG data: USER MUST UPDATE IT (MANDATORY)
//	
//  ======= Tuya CREDENTIALS from plataform.Tuya/cloud + [open projec] /overview
      const data_center = "https://openapi.tuyaeu.com";         // update if required
      const client_id   = "123456789";               // here your Tuya ID 
      const secretkey   = "abcdef123456789";         // here your secret key
//	  const icon_prefix = "https://images.tuyaeu.com";          // to get Tuya icons (not used)

// ======== LOGGING USER OPTIONS (OPTIONAL)
// logFormat: control the file output format: one off  "CSV" | "JSON" | "NONE"
//  note: NONE == NO LOGGING
	  const logFormat = "NONE";
	  
// autosave: time interval for autosave log (if "CSV" | "JSON") in hours 
// note  0 = NO AUTOSAVE	  
      var autoSave = 0;
	  
// loglist: Defines data in LOG file: one row for value
// format: { home: "xxx", device: "yyy", status:"zzzz"},  (care to -"-, -,-). 
// EXAMPLE:	  
      const loglist =[
          { home: "ROMA", device: "TF_frigo", status:"va_temperature"}, 
		  { home: "ROMA", device: "Temperatura studio", status:"va_temperature"},
		  ];

// ========  Timings (OPTIONAL)		  
// note:  tuyaInterval MIN = 20 s (forced)	  
// note:  logInterval  MIN = 60 s (forced) 
      var tuyaInterval = 1*60;   // in seconds  - best min 30  max 10*60
      var logInterval =  5*60;   // in seconds - best  min 2*60 max 30*60

// ========  Look&Feel
// buttonsInteraction: show buttons for pan/zoom (else only mouse).
      const buttonsInteraction = true;

// ======== CONFIG data ends.
 