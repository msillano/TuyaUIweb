/*
This file is part of tuyaUIweb project (https://github.com/msillano/TuyaUIweb)
 contains two custom callback functions: getIcon(), filterDP()
 ------------------------------
License MIT
(C)2024 marco.sillano@gmail.com
version 1.1 20/05/2024
version 1.0 15/05/2024
*/
// ============ local functions	(CUSTOMIZATION optional)
//	
function getIcon(res, type = 'device', connected = false){
// USER TODO ======= Customize icon for some special devices.	
// To select a/all 'special' devices you can use any of:
// - res.name (or res.id)
// - res.product_name
// - res.category
// see https://fontawesome.com/v4/cheatsheet/
	 var   theIcon = {  // default
                    code: "\uf1b2",  // fa-cube
// ISSUE3					
//                 color: "DarkGray", // unconnected color
                   color: "HotPink", // default color
                    };
  // ========  NOT DEVICE ICONS					
	      if (type == 'root')  //  special ROOT icon
             return { code: "\uf174", color: "OrangeRed", size:80 };
          if (type == 'home')  // tuya home :  fa-home
             return { code: "\uf015", color: "SlateGray", size:80};
          if (type == 'room')  // tuya room :  fa-circle
             return { code: "\uf111", color: "DarkCyan"};
			 
 // ==== TODO CUSTOMIZATION icon for special user devices	   
 // EXAMPLE: This works on my system:	 
       if ((res.name.startsWith("Temp"))|| (res.name.startsWith("TF_"))){
                theIcon['code'] = "\uf2c8";
            } else
                if (res.name.startsWith("Termo")) {
                    var icon = 			
                    theIcon['code'] = "\uf045";
                } else
                    if (res.name.includes("Gateway")) {
                        theIcon['code'] = "\uf1eb";
                    }
// ===== USER TODO ENDS			

// ISSUE3		
//	if (connected) 	theIcon['color'] =	"HotPink";
	if (!connected) 	theIcon['color'] =	"DarkGray";
    return (theIcon);
}

function filterDP(res, devData = {status: "none"}){
  if 	(devData == null) devData = {status: "none"};
  
// USER TODO ======= Customize for tooltip optimization.	
// To select a/all 'special' devices you can use any of:
// - res.name (or res.id)
// - res.product_name
// - res.category
//  input/output are object like this: { property1:value1, property2:value2,...}

// EXAMPLE: This works on my system:	 
 	 if (res.name.startsWith("Termo")) {   //Thermovalves for radiators
// in these devices, the temperature is an integer (*10), i.e. the value 237 is 23.7° 
// simple decode of data value for better visualization
		 devData.temp_set = ((devData.temp_set) / 10).toFixed(1)+'°';
	     devData.temp_current = ((devData.temp_current) / 10).toFixed(1)+'°';
	 }
 
// ..... here more ....	 
// ============ CUSTOMIZATION ENDS
	 
	 return devData;    
 }
