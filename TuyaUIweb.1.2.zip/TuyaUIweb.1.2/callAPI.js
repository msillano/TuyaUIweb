/*
This file is part of tuyaUIweb project (https://github.com/msillano/TuyaUIweb)
 js function to access TuyaCloud
 Requires:  config.js, crypto-js, tuyaHTTP.js
 credential global varibles: data_center, client_id,  secretkey  (in config.js)
------------------------------
License MIT
(C)2024 marco.sillano@gmail.com
version 1.0 15/05/2024
*/
 
  // js function to access TuyaCloud
  // Requires:  crypto-js, tuyaHTTP.js
  // credential global varibles: data_centerclient_id  secretkey  
  
  // =============================  local functions 
      var msgTime = null;
    //  access_token: "9362659f1119d9****"
    //  expire_time:  6191
    //  refresh_token:"e01a50d3a******"
	//  uid:          "bay1602265****"
	  var token = null;
 
      function hmacSha256(secret, message)  {
// from https://stackoverflow.com/questions/55718029/converting-crypto-hmac-to-crypto-js-hmac-string    
        const hmac = CryptoJS.algo.HMAC.create(CryptoJS.algo.SHA256, secret);
        hmac.update(message);
        return CryptoJS.enc.Hex.stringify(hmac.finalize());
      }
// crea un digest SHA256 compatibile Tuya	  
	  function sha256(message){
// from https://stackoverflow.com/questions/67840214/equivalent-javascript-code-to-generate-sha256-hash	  
       const utf16le = CryptoJS.enc.Utf16LE.parse(message);
       const utf16Sha256 = CryptoJS.SHA256(utf16le);
       const hashStr = utf16Sha256.toString(CryptoJS.enc.Hex); 
	   return(hashStr);
	  }
	   
	  function _createSignStr1(APIurl){
		  // only for token get
        msgTime = Date.now();
        var method = "GET";
        var content_hash = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
        var string_to_sign = method+"\n"+content_hash+"\n"+""+"\n"+APIurl;
        var _signStr = client_id+msgTime+string_to_sign;
        return hmacSha256(secretkey, _signStr).toString();
        }
	  
	  function _prepareHTTP(method, sign, APIurl, body = null){
    //  only for token get. Same format as HTTP node
        var msg = {};
        msg.method = method;
        msg.headers ={
        // "content-type": "application/json;charset=UTF-8",
        "sign_method": "HMAC-SHA256",
        "client_id" : client_id,
        "t": msgTime.toString(),
        "sign": sign.toUpperCase(),
        }
		msg.payload = body;  
        msg.url = data_center + APIurl;
        return msg;
        }
		
// ======================================================
// main access functions: getCldToken(), getCldRefreshToken(), callAPI(method, APIurl, body) 	
function getCldToken(){
// gets starting token
    const signStr = _createSignStr1("/v1.0/token?grant_type=1");
    const msgHTTP = _prepareHTTP("GET",signStr, "/v1.0/token?grant_type=1");
    token = tuyaHTTP(msgHTTP);
	return ((token.expire_time -600)*1000);
}	  

function getCldRefreshToken(){
// gets refresh token (call it before token expiration)
    const signStr = _createSignStr1("/v1.0/token/"+token.refresh_token);
    const msgHTTP = _prepareHTTP("GET",signStr, "/v1.0/token/"+token.refresh_token);
    token = tuyaHTTP(msgHTTP);
	return ((token.expire_time -600)*1000);

}	  
		
//  generic call to Tuya OpenAPI 
function callAPI(method, APIurl, dbody = null){
    var content_hash;
	if (dbody){
	   content_hash = sha256(dbody);
	}
	else {
	   dbody = '';  // velocizza, SHA256 è noto
       content_hash = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"; 
	};
	msgTime = Date.now();
	const string_to_sign = method+"\n"+content_hash+"\n"+""+"\n"+APIurl;
	const _signStr = client_id + token.access_token+msgTime+string_to_sign;
	const sign = hmacSha256(secretkey, _signStr).toString();
	var msg = {};
		msg.method = method;
		msg.headers ={
		  "mode" : "cors",
		  "Content-Type": "application/json",
		  "sign_method": "HMAC-SHA256",
		  "access_token" : token.access_token,
		  "client_id" : client_id,
		  "sign": sign.toUpperCase(),
		  "t": msgTime.toString(),
		  },

		msg.payload = (dbody == "")? "":JSON.stringify(dbody);
		msg.url = data_center + APIurl;
//		console.log(msg);
        var data = null;
        try {
	       data = tuyaHTTP(msg);
		}
		catch (err){
			console.log(['ERROR tuyaHTTP '+ err, msg]);
			data = null;
 		}
		return data;
  }
